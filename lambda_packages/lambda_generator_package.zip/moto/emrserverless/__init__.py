from .models import emrserverless_backends  # noqa: F401

REGION = "us-east-1"
RELEASE_LABEL = "emr-6.6.0"
