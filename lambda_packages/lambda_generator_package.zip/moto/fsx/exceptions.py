"""Exceptions raised by the fsx service."""
