# Not implemented exceptions for now
